﻿//by PUREHOLIC
//DATE : 2013.07
//VER : 1.0
//COPYRIGHT : CCL CC-BY
//http://pureholic.tistory.com/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mewtocol
{
    
    class Mewtocol : System.IO.Ports.SerialPort
    {
               /// <summary>
       /// 상수!
       /// </summary>
        private const int ENQ = 0x05;
        private const int ACK = 0x06;
        private const int NAK = 0x15;
        private const int EOT = 0x04;
        private const int ETX = 0x03;
        private const int LF = 0x0A;

        private const string Header = "<01#";
        private const string CR = "\r";  //0x0D
        private const int delay_v = 100;
        /// <summary>
        /// 생성자 기본 값 com1 9600
        ///
        /// </summary>
        public void Protocol()
        {
            initializeComponent();
        }

        /// <summary>
        /// 프로토콜 초기화
        /// </summary>
        /// <param name="portName">포트네임</param>
        /// <param name="baudrate">바운드레이트</param>
        public void Protocol(string portName, int baudrate)
        {
            initializeComponent();
            this.PortName = portName;
            this.BaudRate = baudrate;   
            
        }
        //초기화
        private void initializeComponent()
        {
            this.BaudRate = 9600;
            this.StopBits = System.IO.Ports.StopBits.One;
            this.DataBits = 8;
            this.Parity = System.IO.Ports.Parity.Odd;
            this.PortName = "COM1";
            this.ReadTimeout = 500;
        }

        


        
        #region  실 사용 함수 모음! public

        /// <summary>
        /// word 단위 읽기
        /// </summary>
        /// <param name="code">X,Y,R,L,T,C, 사용가능</param>
        /// <param name="address">접점주소 FFFF 16진 표기로</param>
        /// <returns>FFFF 16진 표기로 결과 리턴</returns>
        public string ReadWord(char code,string address)
        {
            string returnV = null;


            
            string temp = Header;
            string senddata = null;
            string readtemp = null;

            temp += "RCC" + code.ToString() + ZeroPlus(4, address) + ZeroPlus(4, address);
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = null; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        returnV = readtemp.ToString()[8].ToString() + readtemp.ToString()[9].ToString() + readtemp.ToString()[6].ToString() + readtemp.ToString()[7].ToString();

                    }
                }
                catch { return returnV = null; }
            }
            

            return returnV;
        }

        /// <summary>
        /// bit 단위로 읽기
        /// </summary>
        /// <param name="code">X,Y,R,L,T,C 접점가능</param>
        /// <param name="data">읽을 데이터주소</param>
        /// <returns>BOOL 놀리값 리턴</returns>
        public bool ReadBit(char code, string data)
        {
            bool returnV = false;
            string temp = Header;
            string senddata=null;
            string readtemp = null;


            temp += "RCS" + code.ToString() + ZeroPlus(4, data);
            
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;
            
            
            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV=false; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        if (readtemp[6] == '1') returnV = true;
                        if (readtemp[6] == '0') returnV = false;
                    }
                }
                catch { return returnV=false; }
            }
            return returnV;
        }
        
        /// <summary>
        /// Word 읽기 
        /// </summary>
        /// <param name="code">D,L,F</param>
        /// <param name="address">접점주소</param>
        /// <returns>문자열 이지만 값은 10진수</returns>
        public string ReadWdata(char code,int address)
        {
            string returnV = null;

            string temp = Header;
            string senddata = null;
            string readtemp = null;
            string readvalue = null;

            temp += "RD" + code.ToString() + ZeroPlus(5, address.ToString()) + ZeroPlus(5, address.ToString());
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = null; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        readvalue = readtemp.ToString()[8].ToString() + readtemp.ToString()[9].ToString() + readtemp.ToString()[6].ToString() + readtemp.ToString()[7].ToString();
                        
                        returnV = Convert.ToInt32(readvalue, 16).ToString();
                    }
                }
                catch { return returnV = null; }
            }
            


            return returnV;
            
        }

        /// <summary>
        /// Double Word 읽기
        /// </summary>
        /// <param name="code">D,L,F</param>
        /// <param name="address">접점주소</param>
        /// <returns>문자열 이지만 값은 10진수</returns>
        public string ReadWDdata(char code, int address)
        {
            string returnV = null;

            string temp = Header;
            string senddata = null;
            string readtemp = null;
            string readvalue = null;

            temp += "RD" + code.ToString() + ZeroPlus(5, address.ToString()) + ZeroPlus(5, (address+=1).ToString());
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = null; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        readvalue = readtemp.ToString()[12].ToString() + readtemp.ToString()[13].ToString() + readtemp.ToString()[10].ToString() + readtemp.ToString()[11].ToString();
                        readvalue += readtemp.ToString()[8].ToString() + readtemp.ToString()[9].ToString() + readtemp.ToString()[6].ToString() + readtemp.ToString()[7].ToString();
                        returnV = Convert.ToInt64(readvalue, 16).ToString();
                    }
                }
                catch { return returnV = null; }
            }



            return returnV;

        }


        /// <summary>
        /// word 단위 데이터 기록
        /// </summary>
        /// <param name="code">Y,R,L 이 사용가능</param>
        /// <param name="address">접점 주소</param>
        /// <param name="data">작성될 값4자리 16진수</param>
        /// <returns>BOOL 논리 데이터 정상시 TRUE</returns>
        public bool WriteWord(char code, string address, string data)
        {
            bool returnV = false;
            
            string cdata = null;
            string temp = Header;
            string senddata = null;
            string readtemp = null;
            
            cdata = data.ToString()[1].ToString() + data.ToString()[0].ToString() + data.ToString()[3].ToString() + data.ToString()[2].ToString();


            temp += "WCC" + code.ToString() + ZeroPlus(4, address) + ZeroPlus(4, address) + cdata + cdata;
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = false; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        returnV = true;

                    }
                }
                catch { return returnV = false; }
            }
            return returnV;

        }


        /// <summary>
        /// bit 단위 쓰기
        /// </summary>
        /// <param name="code">X,R,L 의 접점</param>
        /// <param name="address">접점주소</param>
        /// <param name="data">TRUE FALSE</param>
        /// <returns>부울형식 데이터 수신이 정상적일때 TRUE 리턴</returns>
        public bool Writebit(char code, string address, bool data)
        {
            bool returnV = false;

            char cdata;
            string temp = Header;
            string senddata = null;
            string readtemp = null;

            if (data) { cdata = '1'; } else { cdata = '0'; }

            temp += "WCS" + code.ToString() + ZeroPlus(4, address) + cdata;
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = false; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                         returnV = true;
                       
                    }
                }
                catch { return returnV = false; }
            }
            return returnV;
        }

        /// <summary>
        /// 데이터값 word 단위 입력
        /// </summary>
        /// <param name="code">D,L,F 가능</param>
        /// <param name="address">주서번지</param>
        /// <param name="data">십진수 입력값</param>
        /// <returns>전송결과 부울값 리턴</returns>
        public bool WriteWdata(char code,int address, int data)
        {
            bool returnV = false;

            string cdata = null;
            string temp = Header;
            string senddata = null;
            string readtemp = null;

            cdata = Convert.ToString(data, 16);
            //if( data!=0 )cdata = cdata.Substring(2);
            cdata = ZeroPlus(4, cdata);
            cdata = cdata[2].ToString() + cdata[3].ToString() + cdata[0].ToString() + cdata[1].ToString();
            temp += "WD" + code.ToString() + ZeroPlus(5, address.ToString()) + ZeroPlus(5, address.ToString()) + cdata +cdata;
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = false; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        returnV = true;

                    }
                }
                catch { return returnV = false; }
            }
            return returnV;

        }


        /// <summary>
        /// 데이터값 DOUBLE word 단위 입력
        /// </summary>
        /// <param name="code">D,L,F 가능</param>
        /// <param name="address">주서번지</param>
        /// <param name="data">십진수 입력값</param>
        /// <returns>전송결과 부울값 리턴</returns>
        public bool WriteDWdata(char code,int address, int data)
        {
            bool returnV = false;

            string cdata = null;
            string temp = Header;
            string senddata = null;
            string readtemp = null;

            cdata = Convert.ToString(data, 16);
            //if( data!=0 )cdata = cdata.Substring(2);
            cdata = ZeroPlus(8, cdata);
            cdata = cdata[6].ToString() + cdata[7].ToString() + cdata[4].ToString() + cdata[5].ToString() + cdata[2].ToString() + cdata[3].ToString() + cdata[0].ToString() + cdata[1].ToString();

            temp += "WD" + code.ToString() + ZeroPlus(5, address.ToString()) + ZeroPlus(5, (address+1).ToString()) + cdata;
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = false; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        returnV = true;

                    }
                }
                catch { return returnV = false; }
            }
            return returnV;

        }


        /// <summary>
        /// PLC 현재 상태 값 리턴 01$RT/기종코드2)(버전2)(프로그램용량2)(동작모드2)
        /// /시스템용링크정보 2//에러플래크 2//자기진단에러 4/
        /// </summary>
        /// <returns>문자열 리턴</returns>
        public string StateChech()
        {
            string returnV = null;

            string temp = Header;
            string senddata = null;
            string readtemp = null;

            temp += "RT";
            senddata = temp.ToUpper() + get_bcc_code(temp.ToUpper()) + CR;


            if (this.IsOpen)
            {
                try
                {
                    this.Write(senddata);
                }
                catch { return returnV = "!"; }

                System.Threading.Thread.Sleep(delay_v);

                try
                {
                    readtemp = this.ReadTo(CR);
                    if (readtemp[3] == '$')
                    {
                        returnV = readtemp;

                    }
                }
                catch { return returnV = "!"; }
            }
            return returnV;
        }







        #endregion





        #region sub 함수들 private 지정

        /// <summary>
        /// bcc 코드 생성
        /// </summary>
        /// <param name="data">data string 값</param>
        /// <returns>반환은 xor로 만들어진 2자리의 문자열</returns>
        private string get_bcc_code(string data)
        {
            char[] temp = new char[1024];
            string hex;

            temp = data.ToCharArray(); //문자열을 문자 변수에 각각 집어 넣음


            int bcc = temp[0];

            for (int i = 1; i < temp.Length; i++)
            {
                bcc = bcc ^ temp[i];
            }
            hex = bcc.ToString("X2"); //정수로 계산된 bcc 코드를 16진수로 변경 "X2"는 대문자 16진수 두자리라는 옵션

            //BCC 코드가 대문자여야만 통신이 됨

            return hex.ToUpper();
        }

        /// <summary>
        /// 공백을 지정 길이만큼 0으로 채워서 문자열로 리턴
        /// </summary>
        /// <param name="length">필요 길이 정수값</param>
        /// <param name="data">수정할 문자열</param>
        /// <returns>수정된 문자열</returns>
        private string ZeroPlus(int length, string data)
        {
            string retuneV = null;
            string temp = data;
             

            if (length > data.Length)
            {
                length -= data.Length;
                
                for (int i = 0; i < length ; i++)
                {
                    retuneV +="0";
                }
                
                retuneV += data;

            }else{retuneV = data;}




            return retuneV;
        }









        #endregion





    }
}
