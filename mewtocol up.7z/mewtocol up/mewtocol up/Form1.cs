﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;




namespace mewtocol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Mewtocol plc = new Mewtocol();


        private void button1_Click(object sender, EventArgs e)
        {
           textBox1.Text = plc.ReadBit('r', "10").ToString();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            plc.Protocol("COM5",9600);
            plc.Open();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            plc.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.WriteWord('r', "200", "0fff").ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.WriteWord('r', "200", "0000").ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.ReadWord('y', "0");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.Writebit('r', "2000", true).ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.ReadWdata('d', 0);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.ReadWDdata('d', 200);

        }

        private void button8_Click(object sender, EventArgs e)
        {
            plc.WriteDWdata('d', 300, 12312312);
            //plc.WriteWdata('d', 301, 200);
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text = plc.StateChech();
        }
        

    }
}
